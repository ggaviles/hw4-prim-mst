"""
BMI 203: Biocomputing Algorithms - Winter 2023
HW 4: Prim's Algorithm
"""

from .graph import Graph

__version__ = '0.1.0'
